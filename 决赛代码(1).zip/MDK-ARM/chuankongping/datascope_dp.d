chuankongping\datascope_dp.o: ..\Software\DataScope_DP.C
chuankongping\datascope_dp.o: ..\Software\DataScope_DP.h
